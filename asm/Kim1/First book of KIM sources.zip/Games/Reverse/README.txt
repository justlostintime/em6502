REVERSE
By Jim Butterfield

Start at 0200 - the display will show a combination of 6 letters
such as CDBAEF.  Hit a number from 2 to six to 'flip' letters.
For example, if you hit 2 with the previous example, the first
two letters will flip over to give DCBAEF.  Now if you hit 4,
you'll get the winning combination - ABCDEF - and the display
will signal your win with a line of dashes.

The computer won't limit your number of flips - but try to
get a win in 6 moves or less,  By the way, the computer forbids
doing the same flip twice in succession - so you can't back up a 
move.
