QUICK
By Peter Jennings              
Modified by Jim Butterfield

Description -
   Here's a program to test your speed of reaction. Press
"GO" and the display will blank for a random period of time.
when it lights, hit any numbered button. The number on the
display will tell you how quick you were; the smaller the
number, the faster your reaction time. You may play repeatedly,
just press "GO" each time you want a new test.
